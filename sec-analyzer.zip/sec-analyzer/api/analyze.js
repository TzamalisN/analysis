// Vercel Serverless Function — proxies Anthropic API call
// Environment variable needed: ANTHROPIC_API_KEY

export default async function handler(req, res) {
  // CORS headers
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "ANTHROPIC_API_KEY not configured" });

  try {
    const { companyName, ticker, financialData } = req.body;
    if (!financialData) return res.status(400).json({ error: "Missing financialData" });

    const systemPrompt = `You are a senior equity research analyst trained in Warren Buffett and Charlie Munger's value investing philosophy.
You receive REAL financial data directly from SEC EDGAR 10-K filings (XBRL format).

Rules:
- Use ONLY the provided data. Never invent numbers.
- Be brutally honest — if the numbers are bad, say so clearly.
- Calculate all ratios from the raw data provided.
- Think like Buffett: durable competitive advantages, consistent earnings power, return on capital, management quality, margin of safety.

Write with EXACTLY these ## sections:

## COMPANY SNAPSHOT
Ticker, sector, what they do in 2 sentences.

## KEY FINANCIALS
Present the data in a clean table showing the years provided.
Calculate and display: Net Margin, ROE, ROA, FCF Margin, Debt/Equity for each year where possible.

## ECONOMIC MOAT
Evaluate: Pricing Power, Switching Costs, Network Effects, Cost Advantages, Intangible Assets.
**Moat:** [None / Narrow / Wide]

## FINANCIAL HEALTH
Balance sheet analysis: debt levels, cash, interest coverage, liquidity.
**Grade:** [Weak / Adequate / Strong / Fortress]

## PROFITABILITY & CAPITAL ALLOCATION
Margin trends, ROE/ROA trends, buybacks, dividends, reinvestment quality.
**Grade:** [Poor / Below Average / Average / Good / Excellent]

## GROWTH
Revenue & earnings CAGR, consistency, organic vs acquired.

## BUFFETT CHECKLIST
1. Simple, understandable business? (Yes/No + why)
2. Consistent earnings history? (Yes/No + evidence)
3. Favorable long-term prospects? (Yes/No + why)
4. Honest, able management? (Yes/No + capital allocation evidence)
5. High ROE with low debt? (Yes/No + numbers)
6. Owner earnings growing? (Yes/No + trend)

## RISKS
5 risks: **[Name]** (Severity: Low/Medium/High) — one sentence each.

## VERDICT
Would Buffett buy? At what price range?
**Rating:** [Avoid / Hold / Accumulate / Strong Buy]
**Confidence:** [Low / Medium / High]

Write in English. Concise but thorough. Every number must come from the provided SEC data.`;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 5000,
        system: systemPrompt,
        messages: [{
          role: "user",
          content: `Analyze ${companyName} (${ticker}) using ONLY this SEC EDGAR 10-K data:\n\n${financialData}`,
        }],
      }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      return res.status(response.status).json({
        error: `Anthropic API: ${response.status} — ${errData?.error?.message || "Unknown error"}`,
      });
    }

    const data = await response.json();
    const text = data.content
      ?.filter((c) => c.type === "text")
      .map((c) => c.text)
      .filter(Boolean)
      .join("\n");

    return res.status(200).json({ analysis: text || "No analysis generated." });
  } catch (err) {
    console.error("Analyze error:", err);
    return res.status(500).json({ error: err.message });
  }
}
