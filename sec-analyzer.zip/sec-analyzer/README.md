# NA SEC Equity Analyzer — Οδηγίες Εγκατάστασης

## Τι κάνει
- Τραβάει ΟΛΕΣ τις εταιρείες SEC (~13,000) για αναζήτηση με ticker ή όνομα
- Φέρνει τα πραγματικά financial data από SEC EDGAR (10-K filings, XBRL)  
- Στέλνει τα data στο Claude για Buffett-style ανάλυση
- 1 εταιρεία = 1 SEC request = κανένα rate limit πρόβλημα

## Βήμα 1: GitHub Repository
1. Πήγαινε στο github.com → New Repository
2. Όνομα: `sec-analyzer` (ή ό,τι θες)
3. Public ✓
4. Create repository

## Βήμα 2: Ανέβασε τα αρχεία
Ανέβασε ΑΚΡΙΒΩΣ αυτή τη δομή:

```
sec-analyzer/
├── index.html        ← το frontend
├── vercel.json       ← config
└── api/
    └── analyze.js    ← serverless function (Claude API)
```

Μπορείς να τα ανεβάσεις:
- Από το GitHub UI: "Add file" → "Upload files" 
- Ή με git στο τερματικό

ΣΗΜΑΝΤΙΚΟ: Ο φάκελος `api/` πρέπει να υπάρχει με το `analyze.js` μέσα.

## Βήμα 3: Vercel
1. Πήγαινε στο vercel.com → Sign up με GitHub
2. "Import Project" → Διάλεξε το `sec-analyzer` repo
3. ΠΡΙΝ πατήσεις Deploy:
   - Πάτα "Environment Variables"
   - Name: `ANTHROPIC_API_KEY`
   - Value: (το API key σου από console.anthropic.com)
   - Πάτα Add
4. Deploy!

## Βήμα 4: Χρήση
Ανοίγεις τη σελίδα (π.χ. `sec-analyzer.vercel.app`), γράφεις ticker ή όνομα, τελείωσε.

## API Key
Χρειάζεσαι Anthropic API key:
1. Πήγαινε στο console.anthropic.com
2. Settings → API Keys → Create Key
3. Βάλτο στο Vercel ως environment variable (ANTHROPIC_API_KEY)

Το key δεν φαίνεται ποτέ στον browser — μένει στο Vercel server.

## Κόστος
- SEC EDGAR: ΔΩΡΕΑΝ (για πάντα)
- Vercel: ΔΩΡΕΑΝ (hobby plan)
- Claude API: ~$0.01-0.03 ανά ανάλυση (claude-sonnet-4)
